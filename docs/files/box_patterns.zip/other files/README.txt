These files are NOT USED. I provide the "Sdata" (.DAT) files because the Juki PM-1 software allows patterns to be written in that format (called "sewing standard format vector data"). These may be useful to someone. 

I provide the .PMD files because the Juki PM-1 software saves the patterns in this format. Someone with that program might benefit from having these.

Like the .VDT files, the .DAT files were originally named SD00nnn.DAT. I assume whatever can use them requires that naming convention. (The .PMD files can be named anything.). 
